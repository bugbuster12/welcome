package com.samsung.sn.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.sn.service.InsertPhoneService;

public class MainServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		doGet(request, response);
		
		String url = request.getRequestURI();
		
		if(url.contains("insertForm.do")) {
			try {
				String jsp = new InsertPhoneService().insertPhone(request);
				request.getRequestDispatcher(jsp).forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
