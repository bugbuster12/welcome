package com.samsung.sn.service;

import javax.servlet.http.HttpServletRequest;

public class InsertPhoneService {
	
	public String insertPhone(HttpServletRequest request) {
		return request.getContextPath()+"/view/InsertPhone.jsp";
	}

}
